import { STORAGE_KEYS } from './storageKeys';
import { User } from '@/types/auth';
import { Workspace } from '@/types/workspace';
import { Project } from '@/types/project';
import { Task, Subtask } from '@/types/task';
import { Comment } from '@/types/comment';
import { Notification, ActivityLog } from '@/types/notification';

const isBrowser = typeof window !== 'undefined';

export function getData<T>(key: string, defaultValue: T): T {
  if (!isBrowser) return defaultValue;
  try {
    const item = localStorage.getItem(key);
    if (!item) return defaultValue;
    return JSON.parse(item) as T;
  } catch (error) {
    console.error(`Error reading key "${key}" from localStorage:`, error);
    return defaultValue;
  }
}

export function setData<T>(key: string, value: T): void {
  if (!isBrowser) return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Error writing key "${key}" to localStorage:`, error);
  }
}

export function removeData(key: string): void {
  if (!isBrowser) return;
  try {
    localStorage.removeItem(key);
  } catch (error) {
    console.error(`Error removing key "${key}" from localStorage:`, error);
  }
}

export function clearData(): void {
  if (!isBrowser) return;
  try {
    Object.values(STORAGE_KEYS).forEach((key) => {
      localStorage.removeItem(key);
    });
  } catch (error) {
    console.error('Error clearing localStorage:', error);
  }
}

export function updateData<T>(key: string, updater: (prev: T) => T, defaultValue: T): T {
  const current = getData<T>(key, defaultValue);
  const updated = updater(current);
  setData(key, updated);
  return updated;
}

// Section 7: Required Mock Users & Roles
export const INITIAL_USERS: User[] = [
  {
    id: 'user_hassaan',
    name: 'Hassaan Shahzad',
    email: process.env.NEXT_PUBLIC_OWNER_EMAIL || 'hassaan@acme.com',
    password: process.env.NEXT_PUBLIC_OWNER_PASSWORD || 'Owner@123',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    role: 'Owner',
    department: 'Leadership & Architecture',
    createdAt: new Date(Date.now() - 90 * 86400000).toISOString(),
  },
  {
    id: 'user_sara',
    name: 'Sara',
    email: process.env.NEXT_PUBLIC_ADMIN_EMAIL || 'sara@acme.com',
    password: process.env.NEXT_PUBLIC_ADMIN_PASSWORD || 'Admin@123',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    role: 'Admin',
    department: 'Engineering & Orchestration',
    createdAt: new Date(Date.now() - 80 * 86400000).toISOString(),
  },
  {
    id: 'user_ali',
    name: 'Ali',
    email: 'ali@acme.com',
    password: 'Member@123',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    role: 'Member',
    department: 'Task Collaboration & Execution',
    createdAt: new Date(Date.now() - 60 * 86400000).toISOString(),
  },
  {
    id: 'user_farhan',
    name: 'Farhan',
    email: 'farhan@acme.com',
    password: 'Viewer@123',
    avatarUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&auto=format&fit=crop&q=80',
    role: 'Viewer',
    department: 'Quality Observation',
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
  },
];

export const INITIAL_WORKSPACES: Workspace[] = [
  {
    id: 'ws_acme',
    name: 'Acme Global Platform',
    slug: 'acme-global',
    description: 'Enterprise product development and core infrastructure management',
    icon: 'Layers',
    color: 'indigo',
    ownerId: 'user_hassaan',
    members: [
      { userId: 'user_hassaan', role: 'Owner', joinedAt: new Date(Date.now() - 90 * 86400000).toISOString() },
      { userId: 'user_sara', role: 'Admin', joinedAt: new Date(Date.now() - 80 * 86400000).toISOString() },
      { userId: 'user_ali', role: 'Member', joinedAt: new Date(Date.now() - 60 * 86400000).toISOString() },
      { userId: 'user_farhan', role: 'Viewer', joinedAt: new Date(Date.now() - 30 * 86400000).toISOString() },
    ],
    settings: {
      defaultView: 'kanban',
      allowGuestInvites: true,
      notifyOnTaskAssignment: true,
    },
    createdAt: new Date(Date.now() - 90 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'ws_design',
    name: 'NextGen Design Studio',
    slug: 'nextgen-design',
    description: 'Design system specifications, user research and branding assets',
    icon: 'Palette',
    color: 'emerald',
    ownerId: 'user_hassaan',
    members: [
      { userId: 'user_hassaan', role: 'Owner', joinedAt: new Date(Date.now() - 50 * 86400000).toISOString() },
      { userId: 'user_sara', role: 'Admin', joinedAt: new Date(Date.now() - 40 * 86400000).toISOString() },
      { userId: 'user_ali', role: 'Member', joinedAt: new Date(Date.now() - 30 * 86400000).toISOString() },
    ],
    settings: {
      defaultView: 'list',
      allowGuestInvites: false,
      notifyOnTaskAssignment: true,
    },
    createdAt: new Date(Date.now() - 50 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'proj_core',
    workspaceId: 'ws_acme',
    name: 'Platform 2.0 Architecture',
    key: 'PLT',
    description: 'Next-generation cloud infrastructure, microservices, and speed optimization',
    icon: 'Boxes',
    color: 'indigo',
    status: 'active',
    template: 'saas_launch',
    members: [
      { userId: 'user_hassaan', role: 'lead' },
      { userId: 'user_sara', role: 'contributor' },
      { userId: 'user_ali', role: 'contributor' },
    ],
    customColumns: [
      { id: 'col_backlog', title: 'Backlog', status: 'BACKLOG', order: 0 },
      { id: 'col_todo', title: 'To Do', status: 'TODO', order: 1 },
      { id: 'col_progress', title: 'In Progress', status: 'IN_PROGRESS', order: 2 },
      { id: 'col_done', title: 'Done', status: 'DONE', order: 3 },
    ],
    createdAt: new Date(Date.now() - 45 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'proj_mobile',
    workspaceId: 'ws_acme',
    name: 'iOS & Android Experience',
    key: 'MOB',
    description: 'Universal mobile applications built with offline-first client architecture',
    icon: 'Smartphone',
    color: 'purple',
    status: 'active',
    template: 'sprint_tracker',
    members: [
      { userId: 'user_sara', role: 'lead' },
      { userId: 'user_ali', role: 'contributor' },
    ],
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'proj_quality',
    workspaceId: 'ws_acme',
    name: 'Performance & QA Audit',
    key: 'QA',
    description: 'End-to-end telemetry, edge case regression testing, and security hardening',
    icon: 'ShieldCheck',
    color: 'rose',
    status: 'active',
    template: 'bug_triage',
    members: [
      { userId: 'user_ali', role: 'lead' },
      { userId: 'user_farhan', role: 'viewer' },
    ],
    createdAt: new Date(Date.now() - 15 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'proj_design_kit',
    workspaceId: 'ws_design',
    name: 'Unified Design Token Library',
    key: 'DSK',
    description: 'Multi-brand CSS variables, glassmorphism tokens, and accessible contrast palettes',
    icon: 'Figma',
    color: 'emerald',
    status: 'active',
    template: 'custom',
    members: [
      { userId: 'user_hassaan', role: 'lead' },
      { userId: 'user_ali', role: 'contributor' },
    ],
    createdAt: new Date(Date.now() - 20 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const INITIAL_TASKS: Task[] = [
  {
    id: 'task_1',
    taskNumber: 1,
    workspaceId: 'ws_acme',
    projectId: 'proj_core',
    title: 'Architect centralized client-side localStorage synchronization engine',
    description: 'Implement a zero-latency storage abstraction layer supporting optimistic updates, atomic rollback, and auto-hydration for Next.js App Router.',
    status: 'IN_PROGRESS',
    priority: 'URGENT',
    assigneeId: 'user_hassaan',
    reporterId: 'user_sara',
    dueDate: new Date(Date.now() + 2 * 86400000).toISOString(),
    labels: ['Architecture', 'Performance', 'Storage'],
    attachments: [
      {
        id: 'att_1',
        name: 'storage-architecture-v2.pdf',
        size: 245000,
        type: 'application/pdf',
        url: '#',
        uploadedAt: new Date(Date.now() - 86400000).toISOString(),
      },
    ],
    order: 0,
    createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'task_2',
    taskNumber: 2,
    workspaceId: 'ws_acme',
    projectId: 'proj_core',
    title: 'Design high-density Kanban board with drag-and-drop workflow',
    description: 'Create column grouping for Backlog, To Do, In Progress, and Done with instantaneous state reflections across all view modalities.',
    status: 'IN_PROGRESS',
    priority: 'HIGH',
    assigneeId: 'user_ali',
    reporterId: 'user_hassaan',
    dueDate: new Date(Date.now() + 3 * 86400000).toISOString(),
    labels: ['UI/UX', 'Kanban', 'Frontend'],
    attachments: [],
    order: 1,
    createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'task_3',
    taskNumber: 3,
    workspaceId: 'ws_acme',
    projectId: 'proj_core',
    title: 'Setup role-based access enforcement for Owner, Admin, Member, and Viewer',
    description: 'Protect all state mutations and actions with permission barriers. Block viewers from deleting or editing tasks and fire descriptive Sonner toasts.',
    status: 'TODO',
    priority: 'HIGH',
    assigneeId: 'user_sara',
    reporterId: 'user_hassaan',
    dueDate: new Date(Date.now() + 4 * 86400000).toISOString(),
    labels: ['Security', 'RBAC', 'Redux'],
    attachments: [],
    order: 0,
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'task_4',
    taskNumber: 4,
    workspaceId: 'ws_acme',
    projectId: 'proj_core',
    title: 'Implement Cmd+K command palette with fuzzy search',
    description: 'Provide global keyboard shortcut interaction for fast switching between workspaces, views, project filtering, and rapid task creation.',
    status: 'TODO',
    priority: 'MEDIUM',
    assigneeId: 'user_hassaan',
    reporterId: 'user_sara',
    dueDate: new Date(Date.now() + 6 * 86400000).toISOString(),
    labels: ['Keyboard', 'Productivity'],
    attachments: [],
    order: 1,
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'task_5',
    taskNumber: 5,
    workspaceId: 'ws_acme',
    projectId: 'proj_core',
    title: 'Subtask hierarchy management and progress tracking bar',
    description: 'Support nested subtask checklist, dynamic completion calculation, and bidirectional conversion between tasks and subtasks.',
    status: 'DONE',
    priority: 'MEDIUM',
    assigneeId: 'user_ali',
    reporterId: 'user_hassaan',
    dueDate: new Date(Date.now() - 1 * 86400000).toISOString(),
    labels: ['Subtasks', 'Frontend'],
    attachments: [],
    order: 0,
    createdAt: new Date(Date.now() - 6 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
  },
  {
    id: 'task_6',
    taskNumber: 6,
    workspaceId: 'ws_acme',
    projectId: 'proj_mobile',
    title: 'Optimize biometric auth and offline touch transitions',
    description: 'Ensure gestures and haptic feedback respond in under 16ms on both iOS and Android target builds.',
    status: 'BACKLOG',
    priority: 'LOW',
    assigneeId: 'user_sara',
    reporterId: 'user_hassaan',
    dueDate: new Date(Date.now() + 10 * 86400000).toISOString(),
    labels: ['Mobile', 'Gestures'],
    attachments: [],
    order: 0,
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// Section 17: Support nested subtasks
export const INITIAL_SUBTASKS: Subtask[] = [
  {
    id: 'sub_1',
    taskId: 'task_1',
    parentId: null,
    title: 'Write safe SSR localStorage adapter wrappers',
    completed: true,
    order: 0,
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sub_1_child_1',
    taskId: 'task_1',
    parentId: 'sub_1',
    title: 'Validate browser window check during Next.js rendering',
    completed: true,
    order: 0,
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sub_2',
    taskId: 'task_1',
    parentId: null,
    title: 'Define constant keys and schema validation',
    completed: true,
    order: 1,
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sub_3',
    taskId: 'task_1',
    parentId: null,
    title: 'Configure automated backup export and JSON file validation',
    completed: false,
    order: 2,
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sub_4',
    taskId: 'task_2',
    parentId: null,
    title: 'Build drag-over visual indicator styles with Tailwind',
    completed: true,
    order: 0,
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sub_5',
    taskId: 'task_2',
    parentId: null,
    title: 'Implement fast column switch controls for keyboard accessibility',
    completed: false,
    order: 1,
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const INITIAL_COMMENTS: Comment[] = [
  {
    id: 'comm_1',
    taskId: 'task_1',
    authorId: 'user_sara',
    content: 'Checked the persistence design. Make sure @Hassaan Shahzad JSON import validates keys before committing to Redux state.',
    mentions: ['user_hassaan'],
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
  },
  {
    id: 'comm_2',
    taskId: 'task_1',
    authorId: 'user_hassaan',
    content: 'Agreed @Sara! Added validation with rollback and a clear Sonner error toast on corrupted files.',
    mentions: ['user_sara'],
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
];

export const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: 'notif_1',
    recipientId: 'user_hassaan',
    senderId: 'user_sara',
    type: 'mention',
    title: 'Mentioned in a comment',
    message: 'Sara mentioned you in "Architect centralized client-side localStorage synchronization engine"',
    taskId: 'task_1',
    projectId: 'proj_core',
    read: false,
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
  },
  {
    id: 'notif_2',
    recipientId: 'user_hassaan',
    senderId: 'user_sara',
    type: 'task_assigned',
    title: 'New task assigned',
    message: 'Sara assigned "Implement Cmd+K command palette" to you',
    taskId: 'task_4',
    projectId: 'proj_core',
    read: true,
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
];

export const INITIAL_ACTIVITIES: ActivityLog[] = [
  {
    id: 'act_1',
    workspaceId: 'ws_acme',
    projectId: 'proj_core',
    taskId: 'task_1',
    userId: 'user_hassaan',
    action: 'created task',
    details: 'Architect centralized client-side localStorage synchronization engine',
    timestamp: new Date(Date.now() - 86400000 * 3).toISOString(),
  },
  {
    id: 'act_2',
    workspaceId: 'ws_acme',
    projectId: 'proj_core',
    taskId: 'task_1',
    userId: 'user_hassaan',
    action: 'changed status',
    details: 'Moved from TODO to IN_PROGRESS',
    timestamp: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: 'act_3',
    workspaceId: 'ws_acme',
    projectId: 'proj_core',
    taskId: 'task_5',
    userId: 'user_ali',
    action: 'completed task',
    details: 'Subtask hierarchy management and progress tracking bar marked as DONE',
    timestamp: new Date(Date.now() - 86400000).toISOString(),
  },
];

export function seedInitialDataIfEmpty(): void {
  if (!isBrowser) return;

  // Always sync initial users with modern credentials
  const existingUsers = getData<User[]>(STORAGE_KEYS.USERS, []);
  if (existingUsers.length === 0 || !existingUsers.some(u => u.name.includes('Hassaan'))) {
    setData(STORAGE_KEYS.USERS, INITIAL_USERS);
  }

  if (!localStorage.getItem(STORAGE_KEYS.WORKSPACES)) {
    setData(STORAGE_KEYS.WORKSPACES, INITIAL_WORKSPACES);
  }
  if (!localStorage.getItem(STORAGE_KEYS.PROJECTS)) {
    setData(STORAGE_KEYS.PROJECTS, INITIAL_PROJECTS);
  }
  if (!localStorage.getItem(STORAGE_KEYS.TASKS)) {
    setData(STORAGE_KEYS.TASKS, INITIAL_TASKS);
  }
  if (!localStorage.getItem(STORAGE_KEYS.SUBTASKS)) {
    setData(STORAGE_KEYS.SUBTASKS, INITIAL_SUBTASKS);
  }
  if (!localStorage.getItem(STORAGE_KEYS.COMMENTS)) {
    setData(STORAGE_KEYS.COMMENTS, INITIAL_COMMENTS);
  }
  if (!localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS)) {
    setData(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
  }
  if (!localStorage.getItem(STORAGE_KEYS.ACTIVITIES)) {
    setData(STORAGE_KEYS.ACTIVITIES, INITIAL_ACTIVITIES);
  }
  if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
    setData(STORAGE_KEYS.SETTINGS, {
      theme: 'light', // Section 21: Light Theme is default
      compactMode: false,
      simulateNetworkDelay: false,
      delayMs: 300,
      simulateFailureRate: 0,
      notificationPreferences: {
        taskAssigned: true,
        mentions: true,
        dueDateReminders: true,
        statusChanges: true,
      },
    });
  }
  if (!localStorage.getItem(STORAGE_KEYS.FILTERS)) {
    setData(STORAGE_KEYS.FILTERS, [
      {
        id: 'preset_urgent',
        name: '🔥 Urgent Tasks',
        priority: 'URGENT',
      },
      {
        id: 'preset_in_prog',
        name: '⚡ In Progress',
        status: ['IN_PROGRESS'],
      },
    ]);
  }
}

export function exportAllData(): string {
  if (!isBrowser) return '{}';
  const dump: Record<string, unknown> = {
    exportedAt: new Date().toISOString(),
    version: '1.1.0',
  };
  Object.entries(STORAGE_KEYS).forEach(([name, key]) => {
    try {
      const item = localStorage.getItem(key);
      dump[name] = item ? JSON.parse(item) : null;
    } catch {
      dump[name] = null;
    }
  });
  return JSON.stringify(dump, null, 2);
}

export interface ImportResult {
  success: boolean;
  message: string;
  itemCounts?: {
    workspaces?: number;
    projects?: number;
    tasks?: number;
  };
}

export function importAllData(jsonString: string): ImportResult {
  if (!isBrowser) return { success: false, message: 'Browser environment required' };
  try {
    const parsed = JSON.parse(jsonString);
    if (!parsed || typeof parsed !== 'object') {
      return { success: false, message: 'Invalid JSON file: Root object missing' };
    }

    const keysMap: Record<string, string> = {
      USERS: STORAGE_KEYS.USERS,
      SESSION: STORAGE_KEYS.SESSION,
      WORKSPACES: STORAGE_KEYS.WORKSPACES,
      PROJECTS: STORAGE_KEYS.PROJECTS,
      TASKS: STORAGE_KEYS.TASKS,
      SUBTASKS: STORAGE_KEYS.SUBTASKS,
      COMMENTS: STORAGE_KEYS.COMMENTS,
      NOTIFICATIONS: STORAGE_KEYS.NOTIFICATIONS,
      ACTIVITIES: STORAGE_KEYS.ACTIVITIES,
      SETTINGS: STORAGE_KEYS.SETTINGS,
      FILTERS: STORAGE_KEYS.FILTERS,
    };

    let importedWorkspaces = 0;
    let importedProjects = 0;
    let importedTasks = 0;

    if (parsed.WORKSPACES && Array.isArray(parsed.WORKSPACES)) {
      importedWorkspaces = parsed.WORKSPACES.length;
    }
    if (parsed.PROJECTS && Array.isArray(parsed.PROJECTS)) {
      importedProjects = parsed.PROJECTS.length;
    }
    if (parsed.TASKS && Array.isArray(parsed.TASKS)) {
      importedTasks = parsed.TASKS.length;
    }

    Object.entries(keysMap).forEach(([prop, storageKey]) => {
      if (parsed[prop] !== undefined) {
        localStorage.setItem(storageKey, JSON.stringify(parsed[prop]));
      }
    });

    return {
      success: true,
      message: `Successfully imported ${importedWorkspaces} workspaces, ${importedProjects} projects, and ${importedTasks} tasks.`,
      itemCounts: {
        workspaces: importedWorkspaces,
        projects: importedProjects,
        tasks: importedTasks,
      },
    };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown JSON parse error';
    return { success: false, message: `Import failed: ${message}` };
  }
}
