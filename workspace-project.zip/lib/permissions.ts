import { UserRole } from '@/types/auth';
import { Workspace } from '@/types/workspace';
import { Project } from '@/types/project';
import { Task } from '@/types/task';

export interface PermissionCheckResult {
  allowed: boolean;
  reason?: string;
}

export const PERMISSIONS = {
  // Workspace
  MANAGE_WORKSPACE: ['Owner', 'Admin'] as UserRole[],
  DELETE_WORKSPACE: ['Owner'] as UserRole[],
  INVITE_MEMBERS: ['Owner', 'Admin'] as UserRole[],
  REMOVE_MEMBERS: ['Owner'] as UserRole[],

  // Projects
  CREATE_PROJECT: ['Owner', 'Admin'] as UserRole[],
  EDIT_PROJECT: ['Owner', 'Admin'] as UserRole[],
  DELETE_PROJECT: ['Owner', 'Admin'] as UserRole[],
  ARCHIVE_PROJECT: ['Owner', 'Admin'] as UserRole[],

  // Tasks
  CREATE_TASK: ['Owner', 'Admin', 'Member'] as UserRole[],
  EDIT_TASK: ['Owner', 'Admin', 'Member'] as UserRole[],
  MOVE_TASK: ['Owner', 'Admin', 'Member'] as UserRole[],
  DELETE_TASK: ['Owner', 'Admin', 'Member'] as UserRole[],
  BULK_OPERATIONS: ['Owner', 'Admin', 'Member'] as UserRole[],

  // Subtasks & Comments
  MANAGE_SUBTASKS: ['Owner', 'Admin', 'Member'] as UserRole[],
  ADD_COMMENT: ['Owner', 'Admin', 'Member'] as UserRole[],
  DELETE_COMMENT: ['Owner', 'Admin'] as UserRole[],

  // Settings & Danger Zone
  ACCESS_DANGER_ZONE: ['Owner'] as UserRole[],
  EXPORT_DATA: ['Owner', 'Admin', 'Member', 'Viewer'] as UserRole[],
  IMPORT_DATA: ['Owner', 'Admin'] as UserRole[],
};

export function checkPermission(
  userRole: UserRole | undefined,
  allowedRoles: UserRole[],
  actionName: string
): PermissionCheckResult {
  if (!userRole) {
    return { allowed: false, reason: 'Authentication required' };
  }

  if (allowedRoles.includes(userRole)) {
    return { allowed: true };
  }

  return {
    allowed: false,
    reason: `Access Denied: ${userRole}s cannot ${actionName}.`,
  };
}

export function canCreateTask(role?: UserRole): boolean {
  return !!role && PERMISSIONS.CREATE_TASK.includes(role);
}

export function canEditTask(role?: UserRole, task?: Task, userId?: string): boolean {
  if (!role || role === 'Viewer') return false;
  if (role === 'Owner' || role === 'Admin') return true;
  // Member can edit tasks
  return true;
}

export function canDeleteTask(role?: UserRole, task?: Task, userId?: string): boolean {
  if (!role || role === 'Viewer') return false;
  if (role === 'Owner' || role === 'Admin') return true;
  if (role === 'Member' && task && userId) {
    // Member can delete task if they reported it or are assigned
    return task.reporterId === userId || task.assigneeId === userId;
  }
  return false;
}

export function canManageWorkspace(role?: UserRole): boolean {
  return !!role && PERMISSIONS.MANAGE_WORKSPACE.includes(role);
}

export function canEditWorkspace(role?: UserRole, workspace?: Workspace, userId?: string): boolean {
  if (!role || role === 'Viewer' || role === 'Member') return false;
  if (role === 'Owner') return true;
  if (role === 'Admin') return true;
  return false;
}

export function canDeleteWorkspace(role?: UserRole, workspace?: Workspace, userId?: string): boolean {
  if (!role) return false;
  if (role === 'Owner') return true;
  if (workspace && userId && workspace.ownerId === userId) return true;
  return false;
}

export function canInviteMembers(role?: UserRole): boolean {
  return !!role && PERMISSIONS.INVITE_MEMBERS.includes(role);
}

export function canManageProjects(role?: UserRole): boolean {
  return !!role && PERMISSIONS.CREATE_PROJECT.includes(role);
}

export function canEditProject(role?: UserRole, project?: Project, userId?: string): boolean {
  if (!role || role === 'Viewer') return false;
  if (role === 'Owner' || role === 'Admin') return true;
  if (role === 'Member' && project && userId) {
    return project.members.some((m) => m.userId === userId && m.role === 'lead');
  }
  return false;
}

export function canDeleteProject(role?: UserRole, project?: Project, userId?: string): boolean {
  if (!role || role === 'Viewer') return false;
  if (role === 'Owner' || role === 'Admin') return true;
  if (role === 'Member' && project && userId) {
    return project.members.some((m) => m.userId === userId && m.role === 'lead');
  }
  return false;
}

export function canAccessDangerZone(role?: UserRole): boolean {
  return !!role && PERMISSIONS.ACCESS_DANGER_ZONE.includes(role);
}

export function canManageSettings(role?: UserRole): boolean {
  return !!role && (role === 'Owner' || role === 'Admin');
}
